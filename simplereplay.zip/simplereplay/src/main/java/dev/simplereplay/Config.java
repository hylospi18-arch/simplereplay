package dev.simplereplay;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class Config {
    public static volatile boolean autoRecord = true;

    private Config() {}

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("simplereplay.properties");
    }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) {
            save();
            return;
        }
        try (InputStream in = Files.newInputStream(f)) {
            Properties p = new Properties();
            p.load(in);
            autoRecord = Boolean.parseBoolean(p.getProperty("autoRecord", "true"));
        } catch (IOException e) {
            SimpleReplayClient.LOGGER.warn("Gagal membaca config", e);
        }
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("autoRecord", Boolean.toString(autoRecord));
        try (OutputStream out = Files.newOutputStream(file())) {
            p.store(out, "Simple Replay");
        } catch (IOException e) {
            SimpleReplayClient.LOGGER.warn("Gagal menyimpan config", e);
        }
    }
}
