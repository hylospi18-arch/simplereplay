package dev.simplereplay;

import dev.simplereplay.record.Recorder;
import dev.simplereplay.replay.ReplayManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SimpleReplayClient implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("simplereplay");

    @Override
    public void onInitializeClient() {
        Config.load();
        ReplayManager.register();

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            Recorder.onClientTick(mc);
            ReplayManager.onClientTick(mc);
        });

        ClientPlayConnectionEvents.DISCONNECT.register((handler, mc) -> {
            Recorder.stop();
            ReplayManager.onDisconnect();
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> Recorder.stop());

        LOGGER.info("Simple Replay dimuat. Rekaman disimpan di folder game/simplereplay");
    }
}
