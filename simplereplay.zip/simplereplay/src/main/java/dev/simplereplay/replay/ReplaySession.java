package dev.simplereplay.replay;

import dev.simplereplay.SimpleReplayClient;
import dev.simplereplay.record.Recorder;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.zip.GZIPInputStream;

/**
 * Server Minecraft palsu di 127.0.0.1. Client asli (game kamu) connect ke sini seperti ke server biasa,
 * lalu server ini mengirim ulang paket-paket yang direkam sesuai waktunya.
 */
public final class ReplaySession implements Runnable {

    public record Pos(double x, double y, double z, float yaw, float pitch) {}

    private static final class Rec {
        int type;
        long t;
        byte[] data;
        double x, y, z;
        float yaw, pitch;
    }

    private static final int T_CONFIG = 0;
    private static final int T_PLAY = 1;
    private static final int T_POS = 2;
    private static final int T_KEEPALIVE = 3;

    public static final double[] SPEEDS = {0.25, 0.5, 1.0, 2.0, 4.0, 8.0};

    public volatile boolean paused;
    public volatile boolean follow = true;
    public volatile boolean finished;
    public volatile double virtualMs;
    public volatile Pos pos;
    private volatile int speedIndex = 2;

    private final ServerSocket server;
    private final DataInputStream in;
    private volatile Socket socket;
    private volatile boolean running = true;
    private DataOutputStream out;

    private final AtomicInteger emptyFrames = new AtomicInteger();
    private byte[] keepAlive;
    private Rec peeked;
    private boolean eof;

    public ReplaySession(Path file) throws IOException {
        DataInputStream din = null;
        ServerSocket ss = null;
        try {
            din = new DataInputStream(new GZIPInputStream(
                    new BufferedInputStream(Files.newInputStream(file), 1 << 16), 1 << 16));
            if (din.readInt() != Recorder.MAGIC) {
                throw new IOException("Bukan file replay yang valid");
            }
            if (din.readInt() != Recorder.VERSION) {
                throw new IOException("Versi format replay tidak didukung");
            }
            String mc = din.readUTF();
            String cur = Recorder.minecraftVersion();
            if (!mc.equals(cur)) {
                throw new IOException("Replay ini dari Minecraft " + mc + ", game kamu " + cur);
            }
            ss = new ServerSocket(0, 1, InetAddress.getLoopbackAddress());
        } catch (IOException e) {
            if (din != null) {
                try { din.close(); } catch (IOException ignored) { }
            }
            if (ss != null) {
                try { ss.close(); } catch (IOException ignored) { }
            }
            throw e;
        }
        this.in = din;
        this.server = ss;
    }

    public int port() {
        return server.getLocalPort();
    }

    public void start() {
        Thread t = new Thread(this, "SimpleReplay-Server");
        t.setDaemon(true);
        t.start();
    }

    public void stop() {
        running = false;
        closeQuietly(server);
        Socket s = socket;
        if (s != null) {
            closeQuietly(s);
        }
        closeQuietly(in);
    }

    public double speed() {
        return SPEEDS[speedIndex];
    }

    public void cycleSpeed() {
        speedIndex = (speedIndex + 1) % SPEEDS.length;
    }

    public void changeSpeed(int delta) {
        speedIndex = Math.max(0, Math.min(SPEEDS.length - 1, speedIndex + delta));
    }

    // ---------------------------------------------------------------- thread utama

    @Override
    public void run() {
        try {
            server.setSoTimeout(30_000);
            Socket s = server.accept();
            socket = s;
            s.setTcpNoDelay(true);
            DataInputStream cin = new DataInputStream(new BufferedInputStream(s.getInputStream()));
            out = new DataOutputStream(new BufferedOutputStream(s.getOutputStream()));

            readFrame(cin); // Handshake
            byte[] loginFrame = readFrame(cin); // Login Start
            ByteArrayInputStream li = new ByteArrayInputStream(loginFrame);
            readVarInt(li);
            String name = readString(li);
            byte[] uuid = li.readNBytes(16);

            startDrain(cin);

            // Login Success (1.21.1: UUID, nama, 0 properti, strictErrorHandling=false)
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            writeVarInt(bo, 0x02);
            bo.writeBytes(uuid);
            writeString(bo, name);
            writeVarInt(bo, 0);
            bo.write(0);
            int n0 = emptyFrames.get();
            send(bo.toByteArray());
            waitAck(n0);

            playLoop();
        } catch (Throwable t) {
            if (running) {
                SimpleReplayClient.LOGGER.warn("Replay berhenti: {}", t.toString());
            }
        } finally {
            running = false;
            stop();
            ReplayManager.onSessionEnded(this);
        }
    }

    private void playLoop() throws IOException, InterruptedException {
        long last = System.nanoTime();
        long lastKeepAlive = last;
        int phase = -1;
        int lastN0 = emptyFrames.get();

        while (running) {
            long now = System.nanoTime();
            double dtMs = (now - last) / 1e6;
            last = now;

            if (!paused) {
                virtualMs += dtMs * speed();
                while (running) {
                    Rec r = peek();
                    if (r == null) {
                        finished = true;
                        break;
                    }
                    if (r.type == T_KEEPALIVE) {
                        keepAlive = r.data;
                        next();
                        continue;
                    }
                    if (r.type == T_POS) {
                        if (r.t > virtualMs) {
                            break;
                        }
                        next();
                        pos = new Pos(r.x, r.y, r.z, r.yaw, r.pitch);
                        continue;
                    }
                    if (r.type == T_PLAY && r.t > virtualMs) {
                        break;
                    }
                    // Ganti fase (config <-> play): tunggu client selesai pindah protokol.
                    if (phase != -1 && phase != r.type) {
                        waitAck(lastN0);
                        lastKeepAlive = System.nanoTime();
                        last = lastKeepAlive;
                    }
                    if (r.type == T_PLAY && virtualMs < r.t) {
                        virtualMs = r.t;
                    }
                    next();
                    phase = r.type;
                    lastN0 = emptyFrames.get();
                    send(r.data);
                }
            }

            long nowNs = System.nanoTime();
            if (phase == T_PLAY && keepAlive != null && nowNs - lastKeepAlive > 4_000_000_000L) {
                send(keepAlive);
                lastKeepAlive = nowNs;
            }
            Thread.sleep(2);
        }
    }

    /**
     * Client mengirim paket kosong (hanya ID) saat selesai pindah fase: Login Acknowledged,
     * Finish Configuration, Configuration Acknowledged. Kita tunggu itu sebelum mengirim paket fase baru.
     */
    private void waitAck(int n0) throws InterruptedException {
        long start = System.currentTimeMillis();
        while (running && emptyFrames.get() <= n0 && System.currentTimeMillis() - start < 20_000) {
            Thread.sleep(5);
        }
        Thread.sleep(60);
    }

    // ---------------------------------------------------------------- baca file replay

    private Rec peek() throws IOException {
        if (peeked == null && !eof) {
            peeked = read();
            if (peeked == null) {
                eof = true;
            }
        }
        return peeked;
    }

    private Rec next() {
        Rec r = peeked;
        peeked = null;
        return r;
    }

    private Rec read() {
        try {
            int type = in.read();
            if (type < 0 || type == 255) {
                return null;
            }
            Rec r = new Rec();
            r.type = type;
            switch (type) {
                case T_CONFIG, T_PLAY -> {
                    r.t = in.readLong();
                    int len = in.readInt();
                    r.data = new byte[len];
                    in.readFully(r.data);
                }
                case T_POS -> {
                    r.t = in.readLong();
                    r.x = in.readDouble();
                    r.y = in.readDouble();
                    r.z = in.readDouble();
                    r.yaw = in.readFloat();
                    r.pitch = in.readFloat();
                }
                case T_KEEPALIVE -> {
                    int len = in.readInt();
                    r.data = new byte[len];
                    in.readFully(r.data);
                }
                default -> {
                    return null;
                }
            }
            return r;
        } catch (IOException e) {
            // File terpotong (game crash) atau selesai
            return null;
        }
    }

    // ---------------------------------------------------------------- jaringan

    private void startDrain(DataInputStream cin) {
        Thread t = new Thread(() -> {
            try {
                while (running) {
                    int len = readVarInt(cin);
                    if (len == 1) {
                        // Pastikan ini paket kosong: baca 1 byte ID
                        cin.readFully(new byte[1]);
                        emptyFrames.incrementAndGet();
                    } else {
                        cin.skipNBytes(len);
                    }
                }
            } catch (IOException ignored) {
                // client menutup koneksi
            } finally {
                running = false;
                closeQuietly(server);
            }
        }, "SimpleReplay-Drain");
        t.setDaemon(true);
        t.start();
    }

    private void send(byte[] data) throws IOException {
        writeVarInt(out, data.length);
        out.write(data);
        out.flush();
    }

    private static byte[] readFrame(DataInputStream cin) throws IOException {
        int len = readVarInt(cin);
        if (len < 0 || len > (1 << 21)) {
            throw new IOException("Frame tidak valid: " + len);
        }
        byte[] b = new byte[len];
        cin.readFully(b);
        return b;
    }

    private static void writeVarInt(OutputStream o, int v) throws IOException {
        while ((v & ~0x7F) != 0) {
            o.write((v & 0x7F) | 0x80);
            v >>>= 7;
        }
        o.write(v);
    }

    private static int readVarInt(InputStream i) throws IOException {
        int v = 0;
        int shift = 0;
        while (true) {
            int b = i.read();
            if (b < 0) {
                throw new EOFException();
            }
            v |= (b & 0x7F) << shift;
            if ((b & 0x80) == 0) {
                return v;
            }
            shift += 7;
            if (shift > 35) {
                throw new IOException("VarInt terlalu besar");
            }
        }
    }

    private static String readString(InputStream i) throws IOException {
        int n = readVarInt(i);
        return new String(i.readNBytes(n), StandardCharsets.UTF_8);
    }

    private static void writeString(OutputStream o, String s) throws IOException {
        byte[] b = s.getBytes(StandardCharsets.UTF_8);
        writeVarInt(o, b.length);
        o.write(b);
    }

    private static void closeQuietly(AutoCloseable c) {
        try {
            c.close();
        } catch (Exception ignored) {
        }
    }
}
