package dev.simplereplay.mixin;

import dev.simplereplay.record.Recorder;
import io.netty.channel.ChannelHandlerContext;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketListener;
import net.minecraft.network.ProtocolInfo;
import net.minecraft.network.protocol.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Connection.class)
public abstract class ConnectionMixin {

    @Inject(method = "setupInboundProtocol", at = @At("HEAD"))
    private void simplereplay$onSetupInbound(ProtocolInfo<?> info, PacketListener listener, CallbackInfo ci) {
        Recorder.onInboundProtocol((Connection) (Object) this, info);
    }

    @Inject(
            method = "channelRead0(Lio/netty/channel/ChannelHandlerContext;Lnet/minecraft/network/protocol/Packet;)V",
            at = @At("HEAD"))
    private void simplereplay$onRead(ChannelHandlerContext ctx, Packet<?> packet, CallbackInfo ci) {
        Recorder.onPacket((Connection) (Object) this, packet);
    }
}
