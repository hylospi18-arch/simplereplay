package dev.simplereplay.record;

import dev.simplereplay.Config;
import dev.simplereplay.RecordingStore;
import dev.simplereplay.SimpleReplayClient;
import dev.simplereplay.replay.ReplayManager;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.Connection;
import net.minecraft.network.ConnectionProtocol;
import net.minecraft.network.ProtocolInfo;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.BundlePacket;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.protocol.common.ClientboundKeepAlivePacket;
import net.minecraft.network.protocol.game.ClientboundBundleDelimiterPacket;

import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.zip.GZIPOutputStream;

/**
 * Merekam semua paket server -> client (fase CONFIGURATION dan PLAY) ke file .srp,
 * ditambah posisi/arah pandang pemain lokal tiap tick.
 *
 * Format file (di dalam GZIP):
 *   int MAGIC, int VERSION, UTF versiMinecraft
 *   lalu record-record:
 *     0 = paket config : long t, int len, bytes
 *     1 = paket play   : long t, int len, bytes
 *     2 = posisi       : long t, 3x double, 2x float
 *     3 = frame keepalive (untuk replay) : int len, bytes
 *     255 = akhir
 */
public final class Recorder {
    public static final int MAGIC = 0x53525031; // "SRP1"
    public static final int VERSION = 1;

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss");
    private static final Object LOCK = new Object();

    private static final class Session {
        Connection conn;
        DataOutputStream out;
        long start;
        ProtocolInfo<?> info;
        int phase = -1; // 0 = config, 1 = play
        boolean hadPlay;
        Path file;
        long lastFlush;
        boolean errorLogged;
    }

    private static Session session;

    private Recorder() {}

    public static String minecraftVersion() {
        return FabricLoader.getInstance().getModContainer("minecraft")
                .map(c -> c.getMetadata().getVersion().getFriendlyString())
                .orElse("unknown");
    }

    // ---------------------------------------------------------------- hooks dari mixin

    public static void onInboundProtocol(Connection conn, ProtocolInfo<?> info) {
        try {
            if (!Config.autoRecord || ReplayManager.isActive()) {
                return;
            }
            if (info.flow() != PacketFlow.CLIENTBOUND) {
                return;
            }
            ConnectionProtocol id = info.id();
            synchronized (LOCK) {
                if (id == ConnectionProtocol.CONFIGURATION) {
                    if (session == null || session.conn != conn) {
                        stopLocked();
                        startLocked(conn);
                    }
                    if (session != null) {
                        session.info = info;
                        session.phase = 0;
                    }
                } else if (id == ConnectionProtocol.PLAY) {
                    if (session == null || session.conn != conn) {
                        return;
                    }
                    session.info = info;
                    session.phase = 1;
                    session.hadPlay = true;
                    writeKeepAliveFrame(session);
                }
            }
        } catch (Throwable t) {
            SimpleReplayClient.LOGGER.warn("Recorder: gagal di onInboundProtocol", t);
        }
    }

    public static void onPacket(Connection conn, Packet<?> packet) {
        Session s0 = session;
        if (s0 == null || s0.conn != conn) {
            return;
        }
        synchronized (LOCK) {
            Session s = session;
            if (s == null || s.conn != conn || s.info == null || s.phase < 0) {
                return;
            }
            try {
                if (packet instanceof ClientboundKeepAlivePacket) {
                    return;
                }
                if (packet instanceof BundlePacket<?> bundle) {
                    writeOne(s, new ClientboundBundleDelimiterPacket());
                    for (Object sub : bundle.subPackets()) {
                        if (!(sub instanceof ClientboundKeepAlivePacket)) {
                            writeOne(s, (Packet<?>) sub);
                        }
                    }
                    writeOne(s, new ClientboundBundleDelimiterPacket());
                } else {
                    writeOne(s, packet);
                }
                maybeFlush(s);
            } catch (Throwable t) {
                if (!s.errorLogged) {
                    s.errorLogged = true;
                    SimpleReplayClient.LOGGER.warn("Recorder: gagal merekam paket {}", packet.getClass().getName(), t);
                }
            }
        }
    }

    public static void onClientTick(Minecraft mc) {
        if (session == null) {
            return;
        }
        LocalPlayer p = mc.player;
        if (p == null) {
            return;
        }
        synchronized (LOCK) {
            Session s = session;
            if (s == null || s.phase != 1) {
                return;
            }
            try {
                s.out.writeByte(2);
                s.out.writeLong(System.currentTimeMillis() - s.start);
                s.out.writeDouble(p.getX());
                s.out.writeDouble(p.getY());
                s.out.writeDouble(p.getZ());
                s.out.writeFloat(p.getYRot());
                s.out.writeFloat(p.getXRot());
                maybeFlush(s);
            } catch (IOException e) {
                SimpleReplayClient.LOGGER.warn("Recorder: gagal menulis posisi", e);
            }
        }
    }

    public static void stop() {
        synchronized (LOCK) {
            stopLocked();
        }
    }

    // ---------------------------------------------------------------- internal

    private static void startLocked(Connection conn) {
        try {
            Path f = RecordingStore.dir().resolve("rec-" + LocalDateTime.now().format(FMT) + ".srp");
            GZIPOutputStream gz = new GZIPOutputStream(
                    new BufferedOutputStream(Files.newOutputStream(f), 1 << 16), 1 << 16, true);
            DataOutputStream out = new DataOutputStream(gz);
            out.writeInt(MAGIC);
            out.writeInt(VERSION);
            out.writeUTF(minecraftVersion());
            Session s = new Session();
            s.conn = conn;
            s.out = out;
            s.start = System.currentTimeMillis();
            s.file = f;
            s.lastFlush = s.start;
            session = s;
            SimpleReplayClient.LOGGER.info("Mulai merekam: {}", f);
        } catch (IOException e) {
            SimpleReplayClient.LOGGER.warn("Gagal memulai rekaman", e);
            session = null;
        }
    }

    private static void stopLocked() {
        Session s = session;
        if (s == null) {
            return;
        }
        session = null;
        try {
            s.out.writeByte(255);
            s.out.close();
        } catch (IOException ignored) {
        }
        if (!s.hadPlay) {
            try {
                Files.deleteIfExists(s.file);
            } catch (IOException ignored) {
            }
        } else {
            SimpleReplayClient.LOGGER.info("Rekaman disimpan: {}", s.file);
        }
    }

    private static void maybeFlush(Session s) throws IOException {
        long now = System.currentTimeMillis();
        if (now - s.lastFlush > 2000) {
            s.out.flush();
            s.lastFlush = now;
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static byte[] encode(Session s, Packet<?> p) {
        ByteBuf buf = Unpooled.buffer();
        try {
            StreamCodec<ByteBuf, Packet<?>> codec = (StreamCodec) s.info.codec();
            codec.encode(buf, p);
            byte[] bytes = new byte[buf.readableBytes()];
            buf.readBytes(bytes);
            return bytes;
        } finally {
            buf.release();
        }
    }

    private static void writeOne(Session s, Packet<?> p) throws IOException {
        byte[] bytes = encode(s, p);
        s.out.writeByte(s.phase == 0 ? 0 : 1);
        s.out.writeLong(System.currentTimeMillis() - s.start);
        s.out.writeInt(bytes.length);
        s.out.write(bytes);
    }

    private static void writeKeepAliveFrame(Session s) {
        try {
            byte[] bytes = encode(s, new ClientboundKeepAlivePacket(0L));
            s.out.writeByte(3);
            s.out.writeInt(bytes.length);
            s.out.write(bytes);
        } catch (Throwable t) {
            SimpleReplayClient.LOGGER.warn("Recorder: gagal membuat frame keepalive", t);
        }
    }
}
