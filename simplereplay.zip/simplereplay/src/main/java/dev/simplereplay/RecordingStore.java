package dev.simplereplay;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public final class RecordingStore {
    private RecordingStore() {}

    /** Folder rekaman: &lt;folder game&gt;/simplereplay */
    public static Path dir() {
        Path d = FabricLoader.getInstance().getGameDir().resolve("simplereplay");
        try {
            Files.createDirectories(d);
        } catch (IOException ignored) {
        }
        return d;
    }

    /** Daftar rekaman, yang terbaru di atas. */
    public static List<Path> list() {
        List<Path> out = new ArrayList<>();
        try (Stream<Path> s = Files.list(dir())) {
            s.filter(p -> p.getFileName().toString().endsWith(".srp")).forEach(out::add);
        } catch (IOException e) {
            return out;
        }
        out.sort((a, b) -> Long.compare(modified(b), modified(a)));
        return out;
    }

    private static long modified(Path p) {
        try {
            return Files.getLastModifiedTime(p).toMillis();
        } catch (IOException e) {
            return 0L;
        }
    }
}
