package dev.simplereplay.ui;

import dev.simplereplay.Config;
import dev.simplereplay.RecordingStore;
import dev.simplereplay.replay.ReplayManager;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class ReplayListScreen extends Screen {
    private final Screen parent;
    private List<Path> files = List.of();
    private String error = "";

    public ReplayListScreen(Screen parent) {
        super(Component.literal("Simple Replay"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        files = RecordingStore.list();
        int w = Math.min(320, this.width - 20);
        int x = (this.width - w) / 2;
        int top = 36;
        int bottom = this.height - 56;
        int rows = Math.max(1, Math.min(files.size(), (bottom - top) / 24));

        for (int i = 0; i < rows; i++) {
            Path p = files.get(i);
            this.addRenderableWidget(
                    Button.builder(Component.literal(label(p)), b -> start(p))
                            .bounds(x, top + i * 24, w, 20)
                            .build());
        }

        this.addRenderableWidget(
                Button.builder(autoLabel(), b -> {
                    Config.autoRecord = !Config.autoRecord;
                    Config.save();
                    b.setMessage(autoLabel());
                }).bounds(x, this.height - 50, w, 20).build());

        this.addRenderableWidget(
                Button.builder(Component.literal("Kembali"), b -> this.onClose())
                        .bounds(x, this.height - 26, w, 20)
                        .build());
    }

    private static Component autoLabel() {
        return Component.literal("Rekam otomatis: " + (Config.autoRecord ? "ON" : "OFF"));
    }

    private void start(Path p) {
        String err = ReplayManager.play(p, this.parent);
        if (err != null) {
            error = err;
        }
    }

    private static String label(Path p) {
        String name = p.getFileName().toString().replace(".srp", "");
        try {
            double mb = Files.size(p) / 1048576.0;
            return String.format("%s  (%.1f MB)", name, mb);
        } catch (IOException e) {
            return name;
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        g.drawCenteredString(this.font, this.title, this.width / 2, 14, 0xFFFFFF);
        if (files.isEmpty()) {
            g.drawCenteredString(this.font, Component.literal("Belum ada rekaman."), this.width / 2, 50, 0xAAAAAA);
            g.drawCenteredString(this.font, Component.literal("Main di dunia/server, rekaman dibuat otomatis."),
                    this.width / 2, 64, 0xAAAAAA);
        }
        if (!error.isEmpty()) {
            g.drawCenteredString(this.font, Component.literal(error), this.width / 2, this.height - 66, 0xFF5555);
        }
    }

    @Override
    public void onClose() {
        if (this.minecraft != null) {
            this.minecraft.setScreen(parent);
        }
    }
}
