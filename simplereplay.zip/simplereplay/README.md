# Simple Replay (Fabric 1.21.1)

Mod client-only mirip Flashback versi sederhana.

- Merekam otomatis setiap sesi (dunia singleplayer maupun server) ke `<folder game>/simplereplay/*.srp`.
- Putar ulang dari tombol **Replay** di pojok kiri atas Title Screen.
- Saat replay: tekan ESC untuk tombol Jeda / Kecepatan / Mode (Ikuti atau Freecam).
  Di PC juga ada key: P jeda, `[` `]` kecepatan, G ganti mode.

## Build dari HP (GitHub Actions)
1. Buat repo kosong di GitHub, upload semua isi folder ini (termasuk folder `.github`).
2. Tab Actions -> workflow "Build mod" jalan otomatis.
3. Jar-nya ada di tab Releases (`simplereplay-1.0.0.jar`).
4. Taruh di folder mods instance Fabric 1.21.1 di Zalith Launcher 2, bersama Fabric API.

## Build di PC
`gradle build` (Gradle 8.14, JDK 21) -> `build/libs/simplereplay-1.0.0.jar`

## Batasan
- Tidak ada ekspor video dan tidak bisa seek (maju/mundur bebas), hanya jeda dan atur kecepatan.
- Replay hanya bisa dibuka di versi Minecraft yang sama dengan saat merekam.
- Karakter perekam sendiri tidak ditampilkan (kamera mengikuti posisinya).
