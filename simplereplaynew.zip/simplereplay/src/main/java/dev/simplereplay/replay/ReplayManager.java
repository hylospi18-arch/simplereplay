package dev.simplereplay.replay;

import com.mojang.blaze3d.platform.InputConstants;
import dev.simplereplay.record.Recorder;
import dev.simplereplay.ui.ReplayListScreen;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.GameType;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.nio.file.Path;

public final class ReplayManager {
    private static volatile ReplaySession session;

    private static KeyMapping keyPause;
    private static KeyMapping keyFaster;
    private static KeyMapping keySlower;
    private static KeyMapping keyMode;

    private ReplayManager() {}

    public static boolean isActive() {
        return session != null;
    }

    /** @return pesan error, atau null jika berhasil memulai. */
    public static String play(Path file, Screen parent) {
        if (session != null) {
            return "Replay sedang berjalan";
        }
        Minecraft mc = Minecraft.getInstance();
        ReplaySession s;
        try {
            s = new ReplaySession(file);
        } catch (IOException e) {
            return e.getMessage() == null ? e.toString() : e.getMessage();
        }
        session = s;
        s.start();
        String addr = "127.0.0.1:" + s.port();
        mc.execute(() -> ConnectScreen.startConnecting(
                parent,
                mc,
                ServerAddress.parseString(addr),
                new ServerData("Simple Replay", addr, ServerData.Type.OTHER),
                false,
                null));
        return null;
    }

    static void onSessionEnded(ReplaySession s) {
        if (session == s) {
            session = null;
        }
    }

    public static void onDisconnect() {
        ReplaySession s = session;
        if (s != null) {
            s.stop();
            session = null;
        }
    }

    // ---------------------------------------------------------------- registrasi event

    public static void register() {
        keyPause = KeyBindingHelper.registerKeyBinding(
                new KeyMapping("key.simplereplay.pause", GLFW.GLFW_KEY_P, "key.categories.simplereplay"));
        keyFaster = KeyBindingHelper.registerKeyBinding(
                new KeyMapping("key.simplereplay.faster", GLFW.GLFW_KEY_RIGHT_BRACKET, "key.categories.simplereplay"));
        keySlower = KeyBindingHelper.registerKeyBinding(
                new KeyMapping("key.simplereplay.slower", GLFW.GLFW_KEY_LEFT_BRACKET, "key.categories.simplereplay"));
        keyMode = KeyBindingHelper.registerKeyBinding(
                new KeyMapping("key.simplereplay.mode", GLFW.GLFW_KEY_G, "key.categories.simplereplay"));

        HudRenderCallback.EVENT.register((graphics, tickCounter) -> renderHud(graphics));

        ScreenEvents.AFTER_INIT.register((client, screen, width, height) -> {
            if (screen instanceof TitleScreen && !isActive()) {
                Screens.getButtons(screen).add(
                        Button.builder(Component.literal("Replay"),
                                        b -> client.setScreen(new ReplayListScreen(screen)))
                                .bounds(4, 4, 70, 20)
                                .build());
            } else if (screen instanceof PauseScreen && isActive()) {
                addPauseButtons(screen);
            }
        });
    }

    private static void addPauseButtons(Screen screen) {
        ReplaySession s = session;
        if (s == null) {
            return;
        }
        var buttons = Screens.getButtons(screen);

        buttons.add(Button.builder(Component.literal(s.paused ? "Lanjut" : "Jeda"), b -> {
            s.paused = !s.paused;
            b.setMessage(Component.literal(s.paused ? "Lanjut" : "Jeda"));
        }).bounds(4, 28, 120, 20).build());

        buttons.add(Button.builder(Component.literal("Kecepatan: x" + s.speed()), b -> {
            s.cycleSpeed();
            b.setMessage(Component.literal("Kecepatan: x" + s.speed()));
        }).bounds(4, 52, 120, 20).build());

        buttons.add(Button.builder(Component.literal(s.follow ? "Mode: Ikuti" : "Mode: Freecam"), b -> {
            s.follow = !s.follow;
            b.setMessage(Component.literal(s.follow ? "Mode: Ikuti" : "Mode: Freecam"));
        }).bounds(4, 76, 120, 20).build());
    }

    // ---------------------------------------------------------------- tiap tick

    public static void onClientTick(Minecraft mc) {
        ReplaySession s = session;
        if (s == null) {
            return;
        }
        while (keyPause.consumeClick()) {
            s.paused = !s.paused;
        }
        while (keyFaster.consumeClick()) {
            s.changeSpeed(1);
        }
        while (keySlower.consumeClick()) {
            s.changeSpeed(-1);
        }
        while (keyMode.consumeClick()) {
            s.follow = !s.follow;
        }

        LocalPlayer p = mc.player;
        if (p == null || mc.gameMode == null) {
            return;
        }
        if (mc.gameMode.getPlayerMode() != GameType.SPECTATOR) {
            mc.gameMode.setLocalMode(GameType.SPECTATOR);
        }
        if (s.follow) {
            ReplaySession.Pos pos = s.pos;
            if (pos != null) {
                p.xo = p.getX();
                p.yo = p.getY();
                p.zo = p.getZ();
                p.yRotO = p.getYRot();
                p.xRotO = p.getXRot();
                p.setPos(pos.x(), pos.y(), pos.z());
                p.setYRot(pos.yaw());
                p.setXRot(pos.pitch());
                p.setYHeadRot(pos.yaw());
                p.setDeltaMovement(0, 0, 0);
            }
        }
    }

    // ---------------------------------------------------------------- HUD

    private static void drawRecIndicator(GuiGraphics g, Minecraft mc) {
        int r = 5;
        int cx = g.guiWidth() - 12;
        int cy = 12;
        // Titik merah bulat
        for (int dy = -r; dy <= r; dy++) {
            int half = (int) Math.round(Math.sqrt(r * r - dy * dy));
            g.fill(cx - half, cy + dy, cx + half + 1, cy + dy + 1, 0xFFFF2020);
        }
        String label = "REC";
        int w = mc.font.width(label);
        g.drawString(mc.font, label, cx - r - 4 - w, cy - 4, 0xFFFFFFFF, true);
    }

    private static void renderHud(GuiGraphics g) {
        ReplaySession s = session;
        Minecraft mc = Minecraft.getInstance();
        if (s == null) {
            if (Recorder.isRecording()) {
                drawRecIndicator(g, mc);
            }
            return;
        }
        String state = s.paused ? "JEDA" : s.finished ? "SELESAI" : s.follow ? "IKUTI" : "FREECAM";
        String text = "REPLAY " + fmt(s.virtualMs) + "  x" + s.speed() + "  " + state;
        g.drawString(mc.font, text, 6, 6, 0xFFFFFF, true);
    }

    private static String fmt(double ms) {
        long sec = (long) (ms / 1000.0);
        return String.format("%02d:%02d", sec / 60, sec % 60);
    }
}
